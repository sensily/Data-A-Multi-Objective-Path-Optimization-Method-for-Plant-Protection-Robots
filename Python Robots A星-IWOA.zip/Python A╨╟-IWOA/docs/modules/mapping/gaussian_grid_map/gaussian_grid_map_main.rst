.. _gaussian_grid_map:

Gaussian grid map
-----------------

This is a 2D Gaussian grid mapping example.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Mapping/gaussian_grid_map/animation.gif
