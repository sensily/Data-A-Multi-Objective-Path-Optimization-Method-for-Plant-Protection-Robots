Bug planner
-----------

This is a 2D planning with Bug algorithm.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/PathPlanning/BugPlanner/animation.gif

- `ECE452 Bug Algorithms <https://sites.google.com/site/ece452bugalgorithms/>`_
